**********************************************
** CONSIGNOR-INTEGRASJONS-MODUL FOR MAGENTO **
**********************************************

 Utviklet og selges av Trollweb Solutions AS
 For detaljer se www.trollweb.no

**********************************************************************************

** INSTALLASJON **
1. Overfør filene i de respektive katalogene til din Magento-installasjon (kun nye filer - ingenting blir overskrevet)
2. Gå til Cache-innstillingene i Magento og velg "Clear all" og "Oppdater"
3. Gå i Magento Admin under System -> Innstillinger -> Trollweb -> Consignor
4. Legg inn registreringskode og velg vektenhet
5. Gå i Magento Admin under System -> Web Services -> Roller
6. Opprett ny rolle som heter Consignor, velg Rolleressurser: Consignor
7. Gå i Magento Admin under System -> Web Services -> Brukere
8. Opprett ny bruker som heter consignor, legg inn API key
9. Send API-url og API-brukernavn/passord til kontaktperson hos EDI-Soft
10.Send fraktmetoder for mapping til EDI-Soft

**********************************************************************************

EDI-Soft-integrasjonen er utviklet av Trollweb Solutions AS. 
Kopiering/distribusjon er ikke tillatt. For mer informasjon og bestilling av modul: http://www.trollweb.no/
Lisensen for modulen gjelder pr Magento-installasjon (domene). Dette gjeler også for Partnere/Forhandlere.

